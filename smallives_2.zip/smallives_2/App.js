// App.js

import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Calendar } from 'react-native-calendars';

const Tab = createBottomTabNavigator();

const HomeScreen = () => (
  <View style={styles.tabContainer}>
    <Text style={styles.tabText}>HOME</Text>
  </View>
);

const SettingsScreen = () => (
  <View style={styles.tabContainer}>
    <Text style={styles.tabText}>SETTINGS</Text>
  </View>
);

const ProfileScreen = () => (
  <View style={styles.tabContainer}>
    <Text style={styles.tabText}>PROFILE</Text>
  </View>
);

const OtraInterfazScreen = () => {
  const markedDates = {
    '2024-02-10': { marked: true, dotColor: 'green', description: 'Visitar veterinario' },
    '2024-02-15': { marked: true, dotColor: 'green', description: 'Administrar medicamento' },
    '2024-02-20': { marked: true, dotColor: 'green', description: 'Control de plagas' },
  };

  const tiposDeAnimales = [
    { nombre: 'Perros', color: 'blue' },
    { nombre: 'Gatos', color: 'orange' },
    { nombre: 'Aves', color: 'yellow' },
    { nombre: 'Serpientes', color: 'red' },
    { nombre: 'Insectos', color: 'green' },
  ];

  return (
    <NavigationContainer>
      <ScrollView style={styles.container}>
        <Text style={styles.smallivesText}>Smallives</Text>
        <View style={styles.calendarContainer}>
          <Calendar
            markedDates={markedDates}
            theme={{
              arrowColor: 'black',
              todayTextColor: 'green',
              textDayFontSize: 16,
              textMonthFontSize: 16,
              textDayHeaderFontSize: 16,
            }}
          />
        </View>
        <View style={styles.pendientesContainer}>
          <Text style={styles.pendientesText}>Fechas Pendientes</Text>
          {Object.keys(markedDates).map((date, index) => (
            <View key={index} style={styles.pendienteItem}>
              <View style={styles.pendienteBox}>
                <Text style={styles.pendienteDate}>{date}</Text>
                <Text style={styles.pendienteDescription}>{markedDates[date].description}</Text>
              </View>
            </View>
          ))}
        </View>
        <View style={styles.tiposDeAnimalesContainer}>
          {tiposDeAnimales.map((animal, index) => (
            <View key={index} style={[styles.animalBox, { backgroundColor: animal.color }]}>
              <Text style={styles.animalText}>{animal.nombre}</Text>
            </View>
          ))}
        </View>
        <Tab.Navigator>
          <Tab.Screen name="Home" component={HomeScreen} />
          <Tab.Screen name="Settings" component={SettingsScreen} />
          <Tab.Screen name="Profile" component={ProfileScreen} />
        </Tab.Navigator>
      </ScrollView>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  smallivesText: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'green',
    textAlign: 'center',
    marginVertical: 20,
  },
  calendarContainer: {
    width: '80%',
    alignSelf: 'center',
    marginTop: 20,
  },
  pendientesContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  pendientesText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  pendienteItem: {
    width: '100%',
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  pendienteBox: {
    backgroundColor: 'lightgray',
    padding: 20,
    borderRadius: 10,
    width: '100%',
  },
  pendienteDate: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  pendienteDescription: {
    fontSize: 12,
    color: 'gray',
  },
  tiposDeAnimalesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    flexWrap: 'wrap',
    marginTop: 20,
  },
  animalBox: {
    width: 120,
    height: 80,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  animalText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  tabContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'lightgray',
  },
  tabText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
});

export default OtraInterfazScreen;






